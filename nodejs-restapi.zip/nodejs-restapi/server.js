var express = require('express');
var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json())

var shim = require("security-shim-client-library");
app.use(shim());


require('./app/routes/customer.routes.js')(app);

// Create a Server
var server = app.listen(3000, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("App listening at http://localhost:3000", host, port)

})



exports.create = function(req, res) {
	var newCustomer = req.body;
    customers["customer" + newCustomer.id] = newCustomer;
	console.log("--->After Post, customers:\n" + JSON.stringify(customers, null, 4));
    res.end("Post Successfully: \n" + JSON.stringify(newCustomer, null, 4));
};