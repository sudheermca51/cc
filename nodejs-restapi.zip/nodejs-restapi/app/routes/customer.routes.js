module.exports = function(app) {

    var customers = require('../controllers/customer.controller.js');

    // Create a new Customer
    app.post('/api/customers', customers.create);

    // Retrieve all Customer
    app.get('/api/customers', customers.findAll);

    // Retrieve a single Customer by Id
    app.get('/api/customers/:id', customers.findOne);

    // Update a Customer with Id
    app.put('/api/customers/:id', customers.update);

    // Delete a Customer with Id
    app.delete('/api/customers/:id', customers.delete);

    const ss_client = require('security-shim-client-library');
    
    // inbound and outbound 
    app.post('/api/requestproxy',(req,res,next)=>{
        // Configuring options for request
        // No additonal fields will be supported
        console.log("===================>");
        /* const options = {
            url: '/api/customers/2', 
            //required
            method: 'POST', //required
            body: {
            'subject_value':'Analytics Developer'
            },
        query: {}
         }; */
        ss_client.request_proxy(req, req.body)
        .then(result => {
        //user is authorized to perform 'POST' on 'htt
        // ps://predix-acs.example.predix.io'
        //'result' is the response of 'POST' on 'https
        // ://predix-acs.example.predix.io'
        console.log(result);
            res.json(result);
        })
        .catch(err => {
        console.log('Permission Denied '+err);
            res.json(err)
        });
        }, customers.findAll);

    // check the access for a resource
    app.post('/api/checkAccess',(req,res,next)=>{
        // Configuring options for check_access
        /* const options = {
        resource: 'https://predix-acs.example.predix.io',
        //required
        action: 'GET' //required
        }; */
        ss_client.check_access(req, req.body)
        .then(result => {
        /**
        Result:
        {
        "permission":"Allow/Deny"
        }
        **/
        console.log(result);
        res.json(result);
        })
        .catch(err => {
        console.log('Permission Denied '+err);
        });
    });

    app.post('/api/komal',(req,res,next)=>{
        // Configuring options for check_access
        /* const options = {
        resource: 'https://predix-acs.example.predix.io',
        //required
        action: 'GET' //required
        }; */
        ss_client.check_access(req, req.body)
        .then(result => {
        /**
        Result:
        {
        "permission":"Allow/Deny"
        }
        **/
        console.log(result);
        res.json(result);
        })
        .catch(err => {
        console.log('Permission Denied '+err);
        });
    });

    // inbound and outbound 
    app.post('/api/requestproxy/106',(req,res,next)=>{
        // Configuring options for request
        // No additonal fields will be supported
        console.log("===================>");
        /* const options = {
            url: '/api/customers/2', 
            //required
            method: 'POST', //required
            body: {
            'subject_value':'Analytics Developer'
            },
        query: {}
            }; */
        ss_client.request_proxy(req, req.body)
        .then(result => {
        //user is authorized to perform 'POST' on 'htt
        // ps://predix-acs.example.predix.io'
        //'result' is the response of 'POST' on 'https
        // ://predix-acs.example.predix.io'
        console.log(result);
            res.json(result);
        })
        .catch(err => {
        console.log('Permission Denied '+err);
            res.json(err)
        });
        }, customers.findAll);
    
            // inbound and outbound 
    app.post('/api/requestproxy/107',(req,res,next)=>{
        // Configuring options for request
        // No additonal fields will be supported
        console.log("===================>");
        /* const options = {
            url: '/api/customers/2', 
            //required
            method: 'POST', //required
            body: {
            'subject_value':'Analytics Developer'
            },
        query: {}
            }; */
        ss_client.request_proxy(req, req.body)
        .then(result => {
        //user is authorized to perform 'POST' on 'htt
        // ps://predix-acs.example.predix.io'
        //'result' is the response of 'POST' on 'https
        // ://predix-acs.example.predix.io'
        console.log(result);
            res.json(result);
        })
        
        .catch(err => {
        console.log('Permission Denied '+err);
            res.json(err)
        });
        }, customers.findAll);
}