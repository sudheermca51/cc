package com.ge.ongd.tests.commontests;

import org.apache.commons.logging.*;
import org.testng.annotations.Test;

import com.ge.ongd.commonutils.*;

public class CommonTestNgXMLTest extends MicroAPIBase{

	private static Log logger = LogFactory.getLog(CommonTestNgXMLTest.class);

	String suiteProps, testProps;
	String suiteName = "OGD API Test Suite";
	String testName = "OGD API Tests";
	String uiSuiteName = "OGD UI Test Suite";
	String uiTestName = "OGD UI Tests";
	String fileLoc = getProperty("pcm_api_testng_xml_location")[0] + "/api.xml";
	String uiFileLoc = getProperty("pcm_api_testng_xml_location")[0] + "/ui.xml";
	String packName = "com.ge.ongd.pcm.tests.*";
	
	
	/*************************** API Groups ***************************/ 
	
	@Test
	public void testAPIAll(){
		String[] includedTags = {TestGroups.API};
		String[] excludedTags = {TestGroups.MOBILE, TestGroups.UI};
		
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags, "parallel");
	}
	
	@Test
	public void testAPISanity(){
		String[] includedTags = {TestGroups.SANITY, TestGroups.API};
		String[] excludedTags = {TestGroups.UI, TestGroups.MOBILE};
		
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testAPISmoke(){
		String[] includedTags = {TestGroups.SMOKE, TestGroups.API};
		String[] excludedTags = {TestGroups.UI, TestGroups.MOBILE};
		
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testAPIHigh(){
		String[] includedTags = {TestGroups.HIGH, TestGroups.API};
		String[] excludedTags = {TestGroups.UI, TestGroups.MOBILE};
		
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testMicroService1High(){
		String[] includedTags = {"MicroService1", TestGroups.HIGH};
		String[] excludedTags = {TestGroups.SANITY, TestGroups.UI};
			
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testMicroService1(){
		String[] includedTags = {"MicroService1"};
		String[] excludedTags = {""};
	
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testMicroService2(){
		String[] includedTags = {"MicroService2"};
		String[] excludedTags = {""};
	
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
	
	/*************************** UI Groups ***************************/
	
	@Test
	public void testUIAll(){
		String[] includedTags = {TestGroups.UI};
		String[] excludedTags = {TestGroups.MOBILE, TestGroups.API};
		
		ConstructTestNgXML.constructTestNgXml(uiSuiteName, uiTestName, packName, uiFileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testUISanity(){
		String[] includedTags = {TestGroups.UI, TestGroups.SANITY};
		String[] excludedTags = {TestGroups.API, TestGroups.MOBILE};
		
		ConstructTestNgXML.constructTestNgXml(uiSuiteName, uiTestName, packName, uiFileLoc, includedTags, excludedTags);
	}
	
	@Test
	public void testUIHigh(){
		String[] includedTags = {TestGroups.UI, TestGroups.SANITY};
		String[] excludedTags = {TestGroups.API, TestGroups.MOBILE};
		
		ConstructTestNgXML.constructTestNgXml(uiSuiteName, uiTestName, packName, uiFileLoc, includedTags, excludedTags);
	}
	
	
	/*************************** Priority Groups ***************************/
	@Test
	public void testSmoke(){
		String[] includedTags = {TestGroups.SMOKE};
		String[] excludedTags = {TestGroups.MOBILE};
		
		ConstructTestNgXML.constructTestNgXml(suiteName, testName, packName, fileLoc, includedTags, excludedTags);
	}
}
