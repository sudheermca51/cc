package com.ge.ongd.commonutils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import ru.yandex.qatools.allure.annotations.Attachment;

/**
 * Created by 212629679 on 6/6/2017.
 */
public class MicroUIBase extends MicroAPIBase implements IHookable {

	private static Log logger = LogFactory.getLog(MicroUIBase.class);
	protected static WebDriver driver;
	static String uiConfigPath = "uiconfig.properties";
	static String applicationURL;
	PropertyFileReader reader = new PropertyFileReader();
	String profileId = System.getProperty("profileId");
	String osType = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "osType");
	String browserType = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "browser");
	String getSysOsType = System.getProperty("os.name").toLowerCase();
	boolean coverage = (System.getProperty("coverage") == null) ? false : true;

	/**
	 * Get driver instance, Open the browser and Maximize the browser
	 */
	public void loadBrowser() {
		driver = DriverFactory.getDriverInstance();

		//DriverFactory.maximize();		
		//logger.info("Maximize the browser ::: true");
	}

	/**
	 * Open application url on the browser.
	 */
	public void openURL() {
		loadBrowser(); // Opening Browser

		String getUrl = getApplicationURL();

		navigateToURL(getUrl);
		logger.info("Browser opened successfully with url ::: " + getUrl);
		System.out.println("Browser opened successfully with url ::: " + getUrl);
	}

	@BeforeSuite(alwaysRun = true)
	public void beforeTestSuite() throws Exception {
		if(profileId != null){
			if (!(profileId.contains("API"))) {
				if (!(profileId.contains("CLEANUP"))) {
					DriverFactory.deactivateDriver();
					openURL();
					logger.info("Suite level driver object status ::: " + driver);
					System.out.println("Suite level driver object status ::: " + driver);
				}
			}
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void setUp() throws Exception {
		logger.info("############## Start Test Case Execution ##############");
		System.out.println("############## Start Test Case Execution ##############");
		
		Boolean driverStatus = DriverFactory.getDriverStatus(driver);		
		if(driverStatus) {
			openURL();
			logger.info("Setting Driver Object at Method level ::: " + driver);
			System.out.println("Setting Driver Object at Method level ::: " + driver);
		}else{
			System.out.println("Browser already initiated ::: " + driver);
			logger.info("Browser already initiated ::: " + driver);
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		logger.info("UI Coverage Mode ::: " + coverage);
		System.out.println("UI Coverage Mode ::: " + coverage);
		CollectCodeCoverage.pushCoverage("After Method");
		
		//DriverFactory.closeBrowser();//Close Browser
		logger.info("############## End Test Case Execution ##############");
    	System.out.println("############## End Test Case Execution ##############");
	}

	@AfterSuite(alwaysRun = true)
	public void afterTestSuite() {
		if(profileId != null){
			if (!(profileId.contains("API"))) {
				if (!(profileId.contains("CLEANUP"))) {
					DriverFactory.deactivateDriver();
					DriverFactory.killXvfb();
				}
			}
		}
	}

	/*
	 * getApplicationURL will fetch ui application url from uiconfig.properties
	 * file, if not set system property variable
	 */
	public static String getApplicationURL() {
		PropertyFileReader reader = new PropertyFileReader();
		if (System.getProperty("applicationURL") == null) {
			applicationURL = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath),
					"applicationURL");
		} else {
			applicationURL = System.getProperty("applicationURL");
		}
		logger.info("Application Url ::: " + applicationURL);
		return applicationURL;
	}

	public void navigateToURL(String url) {
		driver.get(url);
	}

	@Attachment(value = "Screenshot of {0}", type = "image/png")
	public byte[] saveScreenshot(String name, WebDriver driver) {
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	}

	@Override
	public void run(IHookCallBack iHookCallBack, ITestResult iTestResult) {
		iHookCallBack.runTestMethod(iTestResult);
		if (iTestResult.getThrowable() != null) {
			saveScreenshot(iTestResult.getName(), driver);
		}
	}

}
