package com.ge.ongd.commonutils;

import java.io.FileWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterSuite;

import com.google.gson.Gson;
import com.jayway.restassured.response.Response;

public class CollectCodeCoverage extends MicroUIBase {

	private static Log logger = LogFactory.getLog(CollectCodeCoverage.class);

	public static void collectClientCodeCoverage(String baseUrl) {
		Response responseBody = null;
		FileWriter writer;
		String uiFileLoc = "src/test/resources/clientCoverage.json";

		//Headers info
		Map<String, Object> headersMap = new LinkedHashMap<String, Object>();
		headersMap.put("content-type", "application/json");

		// post coverage info
		driver.switchTo().defaultContent();
		JavascriptExecutor jse = (JavascriptExecutor) driver;

		Gson gson = new Gson();
		String coverage = gson.toJson(jse.executeScript("return window.__coverage__;"));

		if(coverage != null){
			setSysProperty("ignoreTestProperty", "true");
			try {
				/*writer = new FileWriter(uiFileLoc);
			writer.write(coverage);
			writer.close();
			logger.info("Coverage saved in this location ::: " + uiFileLoc);*/
				responseBody = postServiceResponse(baseUrl + "/coverage/client", headersMap, coverage);
				logger.info(responseBody.getStatusCode());
			} catch (Exception e) {
				e.printStackTrace();
			}
			setSysProperty("ignoreTestProperty", "false");
		}
	}

	public static void pushCoverage(String windowName){
		if(System.getProperty("coverage") != null){
			if(System.getProperty("coverage").equals("true")){
				System.out.println("Collect UI Coverage from window ::: " + windowName);
				logger.info("Collect UI Coverage from window ::: " + windowName);
				CollectCodeCoverage.collectClientCodeCoverage(getApplicationURL());
				logger.info("UI Coverage Collected from window ::: " + windowName);
				System.out.println("UI Coverage Collected from window ::: " + windowName);
			}
		}
	}
}
