package com.ge.ongd.commonutils;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.microtester.common.utils.FileUtil;
import com.ge.microtester.common.utils.RestAssuredUtil;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.DecoderConfig;
import com.jayway.restassured.config.EncoderConfig;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * Created by 212629679 on 6/21/2017.
 */
public class MicroAPIBase extends RestAssuredUtil {

	static Boolean urlEncoded = Boolean.valueOf(true);
	private static Log LOGGER = LogFactory.getLog(MicroAPIBase.class);

	public static Response getServiceResponse(String serviceURL, Map<String, Object> queryParams,
			Map<String, Object> headers) {
		String testPropertyFlag = getIgnoreTestProperty();
		String uri;
		if (!testPropertyFlag.equalsIgnoreCase("true")) {
			uri = getTestProperty(serviceURL);
		} else
			uri = serviceURL;
		uri = normalizeUri(uri);
		LOGGER.info("\nHostname URL --> " + uri + "\n");
		String proxyDetail = proxyDetail();
		RequestSpecification request = RestAssured.given().relaxedHTTPSValidation();
		if (proxyDetail.equalsIgnoreCase("true")) {
			request.proxy(getProxy()[0], Integer.parseInt(getProxy()[1]));
		}
		if ((queryParams != null) && (!queryParams.isEmpty())) {
			String value = "";
			request.queryParameters(queryParams);
		}
		if ((headers != null) && (!headers.isEmpty()))
			request.headers(headers);
		LOGGER.info(queryParams);

		Response response = (Response) request.urlEncodingEnabled(urlEncoded.booleanValue()).when().get(uri,
				new Object[0]);
		LOGGER.info("\nRESPONSE --> " + response.asString() + "\n");
		return response;
	}

	public static Response postServiceResponse(String absfilename, String serviceURL, Map<String, Object> queryParams,
			Map<String, Object> headers, String multiPartParam) throws IOException {
		File providedFile = null;
		String testPropertyFlag = getIgnoreTestProperty();
		String url;
		if (!testPropertyFlag.equalsIgnoreCase("true")) {
			url = getTestProperty(serviceURL);
		} else
			url = serviceURL;
		String uri = normalizeUri(url);
		LOGGER.info("\nHostname URL --> " + uri + "\n");
		String paylaod = FilenameUtils.getExtension(absfilename);
		if ((paylaod.equalsIgnoreCase("txt")) || (paylaod.equalsIgnoreCase("json")) || (paylaod.equalsIgnoreCase("jpg"))
				|| (paylaod.equalsIgnoreCase("csv")) || (paylaod.equalsIgnoreCase("dat"))
				|| (paylaod.equalsIgnoreCase("zip"))) {
			providedFile = new File(absfilename);
			if (!providedFile.exists())
				try {
					throw new Exception("File: " + providedFile.getAbsolutePath() + " doesn't exist.");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
		} else {
			providedFile = FileUtil.genrateFileFromString(absfilename);
		}
		String proxyDetail = proxyDetail();

		RequestSpecification request = RestAssured.given().config(RestAssured.config().encoderConfig(
				EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)));
		if (proxyDetail.equalsIgnoreCase("true")) {
			request.proxy(getProxy()[0], Integer.parseInt(getProxy()[1]));
		}

		if ((!headers.containsValue("multipart/form-data")) || (headers.containsValue("multipart/formdata"))
				|| (headers.containsValue("multipart/mixed"))) {
			if ((queryParams != null) && (!queryParams.isEmpty()))
				request.queryParameters(queryParams);
			if ((headers != null) && (!headers.isEmpty())) {
				request.headers(headers);
			}

			Response response = (Response) request.urlEncodingEnabled(urlEncoded.booleanValue())
					.content(FileUtils.readFileToByteArray(providedFile)).when().post(uri, new Object[0]);
			LOGGER.info("\nRESPONSE --> " + response.asString() + "\n");
			return response;
		}

		if ((queryParams != null) && (!queryParams.isEmpty()))
			request.queryParameters(queryParams);
		if ((headers != null) && (!headers.isEmpty())) {
			request.headers(headers);
		}

		Response response = (Response) request.urlEncodingEnabled(urlEncoded.booleanValue())
				.multiPart(multiPartParam, new File(absfilename)).when().post(uri, new Object[0]);
		LOGGER.info("\nRESPONSE --> " + response.asString() + "\n");
		return response;
	}

	public static Response postServiceResponse(String serviceURL, Map<String, Object> headers, String data)
			throws IOException {
		Boolean urlEncoded = Boolean.valueOf(true);
		String testPropertyFlag = getIgnoreTestProperty();
		String uri;
		if (!testPropertyFlag.equalsIgnoreCase("true")) {
			uri = getTestProperty(serviceURL);
		} else
			uri = serviceURL;
		String url = normalizeUri(uri);
		LOGGER.info("\nHostname URL --> " + url + "\n");
		String proxyDetail = proxyDetail();
		RequestSpecification request = RestAssured.given().config(
				RestAssured.config().decoderConfig(DecoderConfig.decoderConfig().defaultContentCharset("UTF-8")));
		if (proxyDetail.equalsIgnoreCase("true")) {
			request.proxy(getProxy()[0], Integer.parseInt(getProxy()[1]));
		}
		if ((headers != null) && (!headers.isEmpty())) {
			request.headers(headers);
		}

		Response response = (Response) request.urlEncodingEnabled(urlEncoded.booleanValue()).body(data).when().post(url,
				new Object[0]);
		LOGGER.info("\nRESPONSE --> " + response.asString() + "\n");
		return response;
	}

}
