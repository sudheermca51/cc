package com.ge.ongd.commonutils.ui;

import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class HighCharts {

	public ArrayList<ArrayList<Object>> getHighChartPoints(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		ArrayList<ArrayList<Object>> detailsList = (ArrayList<ArrayList<Object>>) js
				.executeScript("return (eval(\"Highcharts.charts[0].series[0].options.data\"))");
		return detailsList;
	}

}
