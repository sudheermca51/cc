package com.ge.ongd.commonutils;

public interface TestGroups {
	
	public static final String SANITY = "Sanity";
	public static final String SMOKE = "Smoke";
	public static final String HIGH = "High";
	public static final String MEDIUM = "Medium";
	public static final String LOW = "Low";
	public static final String REGRESSION = "Regression";

	public static final String UI = "Ui";
	public static final String API = "Api";
	public static final String MOBILE = "Mobile";
	public static final String CRITICAL = "Critical";
}
