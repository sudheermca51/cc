package com.ge.ongd.commonutils.ui;

import com.ge.ongd.commonutils.MicroUIBase;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

/**
 * Created by 212629679 on 6/23/2017.
 */
public class SeleniumUtils extends MicroUIBase {

    @Step("verify if {0} is displayed")
    public static boolean verifyIfElementIsDisplayed(WebElement ele) {
        try {
            if (ele.isDisplayed()) {
                return true;
            } else {
                return false;
            }
        }
        catch (NoSuchElementException e){
            return false;
        }
    }
    
    public static void scrollToElement(WebElement element) {
		try {
			JavascriptExecutor je = (JavascriptExecutor) driver;
			je.executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    public void scrollElementIntoView(WebDriver driver, WebElement element) {

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

	}

	public void waitForPageLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				String loadedvalue = js.executeScript("return document.readyState").toString();
				while (!loadedvalue.equals("complete")) {
					try {
						Thread.sleep(1000);

					} catch (Exception e) {
					}
					loadedvalue = js.executeScript("return document.readyState").toString();
				}
				return loadedvalue.equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(pageLoadCondition);
	}
}
