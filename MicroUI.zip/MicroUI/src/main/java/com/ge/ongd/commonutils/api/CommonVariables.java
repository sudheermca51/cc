package com.ge.ongd.commonutils.api;

public class CommonVariables {
}
