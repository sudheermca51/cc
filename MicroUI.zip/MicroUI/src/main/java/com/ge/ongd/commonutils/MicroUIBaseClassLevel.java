package com.ge.ongd.commonutils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import ru.yandex.qatools.allure.annotations.Attachment;

/**
 * Created by 212629679 on 6/19/2017.
 */
public class MicroUIBaseClassLevel extends TestBase implements IHookable {
    protected WebDriver driver;
    public String uiConfigPath = "uiconfig.properties";

    @BeforeClass(alwaysRun = true)
    public void setUp() throws Exception {
        driver = DriverFactory.getDriverInstance();
        PropertyFileReader reader = new PropertyFileReader();
        if (System.getProperty("applicationURL") == null) {
            String applicationURL = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "applicationURL");
            DriverFactory.navigateToURL(applicationURL);
        } else {
            DriverFactory.navigateToURL(System.getProperty("applicationURL"));
        }
        DriverFactory.maximize();
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        DriverFactory.deactivateDriver();
    }

    @Attachment(value = "Screenshot of {0}", type = "image/png")
    public byte[] saveScreenshot(String name, WebDriver driver) {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    @Override
    public void run(IHookCallBack iHookCallBack, ITestResult iTestResult) {
        iHookCallBack.runTestMethod(iTestResult);
        if (iTestResult.getThrowable() != null) {
            saveScreenshot(iTestResult.getName(), driver);
        }
    }
}
