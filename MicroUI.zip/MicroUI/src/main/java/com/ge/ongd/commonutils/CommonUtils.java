package com.ge.ongd.commonutils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;

import static org.testng.Assert.fail;

public class CommonUtils {
    public static String tagvalue = null;
    public static String csvtag = null;
    public static String StorevariableName;
    public static String StorevariableValue;
    public static HashMap<String, String> hashampcsv = new HashMap<String, String>();
    private static Log logger = LogFactory.getLog(CommonUtils.class);

	/**
	 * getRandomTimeStamp() will generate 2017-02-16T09:45:45.000Z  in <<String>> format
	 *  
	 * @return yyyy-MM-dd'T'HH:mm:ss.SSS'Z' in <<String>> format
	 */
	public static String getRandomTimeStamp(){
		int[] months = new int[] {01, 02, 03, 04};
		int[] days = new int[] {01, 02, 03, 04, 05, 06, 07, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28};
		int[] hours = new int[] {00, 01, 02, 03, 04, 05, 06, 07, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23};
		int[] minutes = new int[] {00, 01, 02, 03, 04, 05, 06, 07, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60};
		int year = 2017;

		int month = months[new Random().nextInt(months.length)];
		int day = days[new Random().nextInt(days.length)];
		int hour = hours[new Random().nextInt(hours.length)];
		int minute = minutes[new Random().nextInt(minutes.length)];
				
		LocalDate startDate = LocalDate.of(year, month, day); //start date		
		String DateFormat = startDate + "T";
		String TimeFormat = String.valueOf(hour) + ":" + String.valueOf(minute) + ":" + String.valueOf(minute) +".000Z";
		return DateFormat + TimeFormat;
	}
	
	/**
	 * getRandomEpoch() will generate epoch time format
	 * 
	 * Input Format : dd-MM-YYYY HH:mm:ss
	 * @return <<String>> format
	 */
	public static String getRandomEpoch(){		
		String timeStamp = getRandomTimeStamp();
		String epochStartTime = CommonUtils.convertUTCDateToEpochFormat(timeStamp)+"";	
		logger.info("Epoch Timestamp :" + timeStamp);
		return epochStartTime;		
	}
	
	/**
     * Converting the Epoch Time to Date Format as displayed in the UI
     * Format : dd-MM-YYYY HH:mm:ss
     *
     * @param time
     * @return
     */
	
    public static String convertEpochToDateFormat(double time, String... type) {
        long timeinmillis = 0;
        Date d = null;
        SimpleDateFormat sdf = null;        
        if(type != null && type.length>=1){
        	timeinmillis = (long) (time); 
        	d = new Date(timeinmillis);
            sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            return sdf.format(d);
        } else{
        	timeinmillis = (long) (time * 1000);
        	d = new Date(timeinmillis);
            sdf = new SimpleDateFormat("dd-MM-YYYY HH:mm:ss");
            return sdf.format(d);
        }
    }
    
    public static long convertUTCDateToEpochFormat(String time) {
    	long epoch = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date datenew =  null;
		try {
			datenew = (Date) sdf.parse(time);
		} catch (ParseException e) {
			logger.error(e);
		}
        epoch = datenew.getTime();
        return epoch;
    }

    public static long convertDateToEpochFormat(String str) {
		long epoch = 0;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
			Date date = df.parse(str);
			epoch = date.getTime();
		} catch (Exception e) {
			logger.error(e);
		}
		return epoch;
	}

	public static long getEpochDate(String str) {
		long epoch = 0;
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy MM dd HH:mm:ss aaa");
			Date date = df.parse(str);
			epoch = date.getTime();
		} catch (Exception e) {
			logger.error(e);
		}
		return epoch;
	}
	
    public static String getTestResourceAbsoluteFilePath(String fileName) {
        ClassLoader classLoader = DriverFactory.class.getClassLoader();
        File file = new File(classLoader.getResource(fileName).getFile());
        file.setExecutable(true);
        return file.getAbsolutePath();
    }

    public static String readFile(String fileName) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        try {
            StringBuffer sb = new StringBuffer();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append("\n");
                line = br.readLine();
            }
            return sb.toString();
        } finally {
            br.close();
        }
    }

    /**
     * <p>Read the Data from TestData CSV FIle based on label value</p>
     * <p>Eg: getTestData("Predix")</p>
     *
     * @param tag - label from testData
     * @return Value of the label from testDataFile
     * Created by 212629684
     */
    public static String getTestData(String tag) {
        tagvalue = "";
        Set<String> keySet = CommonUtils.hashampcsv.keySet();
        for (Object key : keySet) {
            if (key.equals(tag)) {
                String temp = CommonUtils.hashampcsv.get(key).toString();
                if (temp.contains("~"))
                    tagvalue = temp.replace("~", ",");
                else
                    tagvalue = temp;

            }
        }
        return tagvalue;
    }

    /**
     * <p>Load the test data CSV files into Hashmap</p>
     * <p>Eg: loadcsv ("TestData")</p>
     *
     * @return Hashmap with all TestData loaded
     * @throws Exception,IOException Created by 212629684
     */
    public static HashMap<String, String> loadcsv(String filePath) throws IOException, Exception {
        String[] Values = null;
        File strFile = null;
        strFile = new File(getTestResourceAbsoluteFilePath(filePath + ".csv"));
        logger.info("The TestData file location is" + strFile);
        // create BufferedReader to read csv file
        if (strFile == null) {
            fail("TestData CSV file: not found");
        }
        BufferedReader br = new BufferedReader(new FileReader(strFile));
        String strLine = "";
        while ((strLine = br.readLine()) != null) {
            Values = strLine.split(",");
            if (Values.length > 1)
                CommonUtils.hashampcsv.put(Values[0], Values[1]);
        }

        br.close();
        return CommonUtils.hashampcsv;
    }

    /**
     * Read RHS value from TestDatafile from ParameterStringReference label
     * <p>Eg: GetValuefromParamList("Predix","tag");</p>
     *
     * @param paramStringReference - label provided in testdata CSV.
     * @param fieldName            - LHS Value from String Reference.
     *                             <p>For example In TestData CSV TestData String is <p>Predix,tag="tag1";team1="tag2";team2="tag4";team3=text</p>
     *                             <p>ParamStringReference is "Predix"</p>
     *                             <p>FldName are "tag1","tag2","tag4",text</p>
     * @return RHS Value from StringReference of multiple Data
     * @throws Exception Created by 212629684
     */
    public static String getValuefromParamList(String paramStringReference, String fieldName) throws Exception {
        String csvvalue = "", LHS, tempy = "";
        String stringmethod = getTestData(paramStringReference);
        String[] Params = stringmethod.split(";");
        for (int i = 0; i < Params.length; i++) {
            if (Params[i].contains("=")) {
                String[] LHSRHS = Params[i].split("=");
                LHS = LHSRHS[0];
                if (LHS.equalsIgnoreCase(fieldName)) {
                    tempy = LHSRHS[1];

                    if (tempy.contains("\"")) {
                        tempy = tempy.replace("\"", "");
                        csvvalue = tempy;
                    } else

                        csvvalue = getTestData(fieldName);
                }
            } else if (Params[i].contains("->")) {
                String[] LHSRHS = Params[i].split("->");
                LHS = LHSRHS[0];
                if (LHS.equalsIgnoreCase(fieldName)) {
                    csvtag = LHSRHS[1];
                    csvvalue = getTestData(csvtag);
                }
            }
        }
        return csvvalue;
    }

    /**
     * <p>Store a variable into TestDataHashmap</p>
     * <p>Eg: StoreVariable("team3", "tag8");</p>
     *
     * @param variableName  - Variable name declared in script which should be stored in hashmap
     * @param variableValue - A value where this variable should be stored in Hashmap.This is taken as a key for hashmap
     *                      Created by 212629684
     */
    public static void storeVariable(String variableName, String variableValue) {
        StorevariableName = variableName;
        StorevariableValue = variableValue;
        CommonUtils.hashampcsv.put(StorevariableName, StorevariableValue);
    }
}
