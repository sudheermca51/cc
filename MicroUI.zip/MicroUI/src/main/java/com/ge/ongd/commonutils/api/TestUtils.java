package com.ge.ongd.commonutils.api;

import com.ge.ongd.commonutils.MicroAPIBase;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;

public class TestUtils extends MicroAPIBase {
    private static Log logger = LogFactory.getLog(TestUtils.class);

    public static void validateResponseStatusCode(Response responseBody, int... responseCode) {
    	int statusCode = 0;
    	
    	if(responseCode != null && responseCode.length>=1) statusCode = responseCode[0];
    	else statusCode = 200;
    	
    	if (responseBody != null) {
            logger.info("\nRESPONSE --> " + responseBody.asString() + "\n");
            isEqual("Response Failed", statusCode, responseBody.getStatusCode());
        }
    }
    
    public static String extractPredixRunId(Response responseBody) {
        JsonPath jsonPath = new JsonPath(responseBody.getBody().asString());
        String getRunId = jsonPath.get("runId");
        logger.info("\nRUN ID --> " + getRunId + "\n");
        return getRunId;
    }

    public static String extractAirflowRunId(Response responseBody) {
        JsonPath jsonPath = new JsonPath(responseBody.getBody().asString());
        String getRunId = jsonPath.getString("output.stdout.runId");
        logger.info("\nRUN ID --> " + getRunId + "\n");
        return getRunId;
    }

	/*
     * Get total number of objects in a response
	 */

    public int getNumberOfObjects(Response response) throws JSONException {
        try {
            JSONArray array = new JSONArray(response.asString());
            return array.length();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

    }

    public static JSONArray sortJSONArrayBasedOnKey(String order, JSONArray jsonArrayBeforeSorting, String key)
            throws Exception {
        if (order.equals("asc")) {
            JSONArray jsonSortedArray = new JSONArray();
            List<JSONObject> jsonObjectList = new ArrayList<JSONObject>();
            for (int i = 0; i < jsonArrayBeforeSorting.length(); i++) {
                jsonObjectList.add(jsonArrayBeforeSorting.getJSONObject(i));
            }

            Collections.sort(jsonObjectList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    String value1 = new String();
                    String value2 = new String();
                    try {
                        value1 = (String) o1.get(key);
                        value2 = (String) o2.get(key);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return value1.compareTo(value2);
                }
            });

            for (int i = 0; i < jsonArrayBeforeSorting.length(); i++) {
                jsonSortedArray.put(jsonArrayBeforeSorting.get(i));
            }

            return jsonSortedArray;
        } else if (order.equals("desc")) {
            JSONArray jsonSortedArray = new JSONArray();
            List<JSONObject> jsonObjectList = new ArrayList<JSONObject>();
            for (int i = 0; i < jsonArrayBeforeSorting.length(); i++) {
                jsonObjectList.add(jsonArrayBeforeSorting.getJSONObject(i));
            }

            Collections.sort(jsonObjectList, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject o1, JSONObject o2) {
                    String value1 = new String();
                    String value2 = new String();
                    try {
                        value1 = (String) o1.get(key);
                        value2 = (String) o2.get(key);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return value2.compareTo(value1);
                }
            });

            for (int i = 0; i < jsonArrayBeforeSorting.length(); i++) {
                jsonSortedArray.put(jsonArrayBeforeSorting.get(i));
            }

            return jsonSortedArray;
        } else {
            return null;
        }
    }

    public HashMap<String, ArrayList<String>> getOrchestrationDetailsMap(Response response) throws JSONException {
        JsonPath jsonPath = new JsonPath(response.asString());
        JSONArray array = new JSONArray(response.asString());
        HashMap<String, ArrayList<String>> detailsMap = new HashMap<String, ArrayList<String>>();

        for (int i = 0; i < array.length(); i++) {
            ArrayList<String> valueList = new ArrayList<String>();

            valueList.add(jsonPath.getString("[" + i + "].name"));
            valueList.add(jsonPath.getString("[" + i + "].description"));

            String orchestrationIndex = jsonPath.getString("[" + i + "].orchid");
            detailsMap.put(orchestrationIndex, valueList);
        }

        return detailsMap;

    }
}
