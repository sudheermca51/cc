package com.ge.ongd.commonutils;

import com.ge.microtester.common.utils.RestAssuredUtil;

/**
 * Created by 212629679 on 6/21/2017.
 */
public class TestBase extends RestAssuredUtil
{
}
