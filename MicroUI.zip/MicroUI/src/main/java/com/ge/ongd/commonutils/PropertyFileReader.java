package com.ge.ongd.commonutils;

import java.io.FileReader;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by 212629679 on 6/15/2017.
 */
public class PropertyFileReader {
    public String propertiesReader(String filePath, String key) {
        try {
            Properties properties = new Properties();
            FileReader reader = new FileReader(filePath);
            properties.load(reader);
//            InputStream configStream = this.getClass().getResourceAsStream(filePath);
//            properties.load(configStream);
            String s = properties.getProperty(key);
            return s;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
