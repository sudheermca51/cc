package com.ge.ongd.commonutils;

import java.io.IOException;
import java.util.logging.Level;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.ge.microtester.common.utils.RestAssuredUtil;

public class DriverFactory extends RestAssuredUtil{
	private static Log logger = LogFactory.getLog(DriverFactory.class);
    private static WebDriver driver;
    private static String uiConfigPath = "uiconfig.properties";

    private static WebDriver instantiateWebDriver() {
        PropertyFileReader reader = new PropertyFileReader();

        if (System.getProperty("browser") == null) {
            String browserName = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "browser");
            if (browserName.equalsIgnoreCase("chrome")) {
                useChromeAsBrowser();

            } else if (browserName.equalsIgnoreCase("firefox")) {
                useFirefoxAsBrowser();

            } else if (browserName.equalsIgnoreCase("ie") ||
                    browserName.equalsIgnoreCase("InternetExplorer") ||
                    browserName.equalsIgnoreCase("internet explorer")) {
                useIEAsBrowser();

            } else if (browserName.equalsIgnoreCase("edge")) {
                useEdgeAsBrowser();
            }
        } else {
            if (System.getProperty("browser").equalsIgnoreCase("chrome")) {
                useChromeAsBrowser();
            } else if (System.getProperty("browser").equalsIgnoreCase("firefox")) {
                useFirefoxAsBrowser();
            }
        }

        return driver;
    }

    public static Boolean getDriverStatus(WebDriver driver){
    	Boolean status = false;    	
    	if(driver != null){
    		status = driver.toString().contains("null");
    	}else status = true;
    	return status;
    }
    
    public static WebDriver getDriverInstance() {    	
    	Boolean driverStatus = getDriverStatus(driver);
    	
    	if (driverStatus) {
            driver = instantiateWebDriver();
            setDriver(driver);
        }        
        return driver;
    }

    private static void setDriver(WebDriver driver2) {
        driver = driver2;
    }

    public static void closeBrowser(){
    	System.out.println("Close Browser ::: " + driver);
    	driver.quit();
    	System.out.println("Browser closed ::: " + driver);
    	logger.info("!!!!!!!!!!!! Quit browser instance !!!!!!!!!!!!");
    	System.out.println("!!!!!!!!!!!! Quit browser instance !!!!!!!!!!!!");    			
    }
    
    public static void oldDeactivateDriver() {    	        
    	logger.info("!!!!!!!!!!!! Initiated Closing browser !!!!!!!!!!!!");
		
    	PropertyFileReader reader = new PropertyFileReader();
    	// hostName = localhost or remote
    	// if hostName=localhost, it will trigger driver.quit browser
    	// if hostName=remote, it will kill chromedriver & Chrome browser
    	
    	String hostMachine;
    	String browser;
    	hostMachine = System.getProperty("hostMachine");
    	
    	if (System.getProperty("hostMachine") == null) {
    		hostMachine = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "hostMachine");
        }else{
        	hostMachine = System.getProperty("hostMachine");
        }
    	
		browser = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "browser");
		
		if(System.getProperty("os.name").equalsIgnoreCase("LINUX")){
			hostMachine = "remote";
			System.out.println(System.getProperty("os.name") + " :::: " + hostMachine);
			logger.info(System.getProperty("os.name") + " :::: " + hostMachine);
		}
		
		try {
			if (!(hostMachine.equals("localhost")) && browser.equals("chrome")) {
				
	            if (System.getProperty("os.name").toLowerCase().indexOf("windows") > -1) {
	    			Runtime rt = Runtime.getRuntime();
					rt.exec("taskkill /F /IM chromedriver.exe");
				} else {
					//Killing chromedriver forcefully
					new ProcessBuilder("/bin/bash", "-c", "ps aux | grep -i chromedriver | awk {'print $2'} | xargs kill -9").start();

					//Killing Chrome browser forcefully
					new ProcessBuilder("/bin/bash", "-c", "ps -eo pid,args | grep -i Chrome |awk '{print $1}' | xargs kill -9").start();									
				}
				logger.info("!!!!!!!!!!!! Killed browser instance !!!!!!!!!!!!");
				System.out.println("!!!!!!!!!!!! Killed browser instance !!!!!!!!!!!!");
	        }else{
	        	driver.quit();
	        	logger.info("!!!!!!!!!!!! Quit browser instance !!!!!!!!!!!!");
	        	System.out.println("!!!!!!!!!!!! Quit browser instance !!!!!!!!!!!!");
	        }			
		} catch (IOException e) {
			logger.error("Unable to Close Browser::: \n" + e);
		}
		driver = null;
		logger.info("!!!!!!!!!!!! Setting driver object to Null !!!!!!!!!!!!");
		System.out.println("!!!!!!!!!!!! Setting driver object to Null!!!!!!!!!!!!");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
    
    public static void deactivateDriver(){
    	String browser;
    	PropertyFileReader reader = new PropertyFileReader();    	
		browser = reader.propertiesReader(CommonUtils.getTestResourceAbsoluteFilePath(uiConfigPath), "browser");
    	
		if (System.getProperty("browser") == null && browser == null) {
    		browser = "chrome";
    		System.out.println("Default Browser set to :::: " + browser);
			logger.info("Default Browser set to :::: " + browser);
        }		
		
		if(browser.equalsIgnoreCase("chrome")){
			deactivateChromeDriver();
		}else if(browser.equalsIgnoreCase("firefox")){
			//Kill Firefox Driver
		}else{
			deactivateChromeDriver(); // By default Kill Chrome browser, Chromedriver & XVfb
		}
    }
    
    /*
     * if OsType is mac, it will trigger driver.quit browser
     * if OsType is linux, it will kill xvfb, chromedriver & Chrome browser
     * if OsType is windows, it will kill chromedriver
     * */
    public static void deactivateChromeDriver() {    	    	    	
    	logger.info("!!!!!!!!!!!! Initiated Closing browser !!!!!!!!!!!!");
    	System.out.println("!!!!!!!!!!!! Initiated Closing browser !!!!!!!!!!!!");

		try {				
            if (System.getProperty("os.name").toLowerCase().indexOf("windows") > -1) {
    			Runtime rt = Runtime.getRuntime();
				rt.exec("taskkill /F /IM chromedriver.exe");
				
				logger.info("!!!!!!!!!!!! Killed Windows chromedriver instance !!!!!!!!!!!!");
				System.out.println("!!!!!!!!!!!! Killed Windows chromedriver instance !!!!!!!!!!!!");
				
			} else if(System.getProperty("os.name").equalsIgnoreCase("LINUX")) {
				//Killing Chrome browser forcefully
				new ProcessBuilder("/bin/bash", "-c", "ps -eo pid,args | grep -i Chrome | awk '{print $1}' | xargs kill -9").start();									

				//Killing chromedriver forcefully
				new ProcessBuilder("/bin/bash", "-c", "ps -eo pid,args | grep -i chromedriver | awk '{print $1}' | xargs kill -9").start();
				
				logger.info("!!!!!!!!!!!! Killed Linux's browser, chromedriver instance !!!!!!!!!!!!");
				System.out.println("!!!!!!!!!!!! Killed Linux's browser, chromedriver instance !!!!!!!!!!!!");
			}else{
				driver.quit();
			}
		} catch (IOException e) {
			logger.error("Unable to Close Browser ::: \n" + e);
		}
		
		driver = null;
		logger.info("!!!!!!!!!!!! Setting driver object to Null !!!!!!!!!!!!");
		System.out.println("!!!!!!!!!!!! Setting driver object to Null!!!!!!!!!!!!");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
    
    public static void startXvfb() {    	    	    	
    	logger.info("!!!!!!!!!!!! Start Xvfb !!!!!!!!!!!!");
    	System.out.println("!!!!!!!!!!!! Start Xvfb !!!!!!!!!!!!");

		try {				
            if (System.getProperty("os.name").toLowerCase().indexOf("windows") > -1) {
    			// Start Xvfb for Windows				
			} else if(System.getProperty("os.name").equalsIgnoreCase("LINUX")) {				
				//Start Xvfb for Linux
				new ProcessBuilder("/bin/bash", "-c", "Xvfb :25 & export DISPLAY=:25").start();				
			}
		} catch (IOException e) {
			logger.error("Unable to Start Xvfb Session ::: \n" + e);
		}
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
    
    public static void killXvfb() {    	    	    	
    	logger.info("!!!!!!!!!!!! Kill Xvfb !!!!!!!!!!!!");
    	System.out.println("!!!!!!!!!!!! Kill Xvfb !!!!!!!!!!!!");

		try {				
            if (System.getProperty("os.name").toLowerCase().indexOf("windows") > -1) {
    			// Kill Xvfb for Windows				
			} else if(System.getProperty("os.name").equalsIgnoreCase("LINUX")) {				
				//Killing xvfb forcefully
				new ProcessBuilder("/bin/bash", "-c", "ps -eo pid,args | grep -i Xvfb | awk '{print $1}' | xargs kill -9").start();				
			}
		} catch (IOException e) {
			logger.error("Unable to Kill Xvfb Session ::: \n" + e);
		}
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }

    public static void useEdgeAsBrowser() {
        System.setProperty("webdriver.edge.driver", CommonUtils.getTestResourceAbsoluteFilePath("MicrosoftWebDriver.exe"));
        driver = new InternetExplorerDriver();
    }

    public static void useIEAsBrowser() {
        System.setProperty("webdriver.ie.driver", CommonUtils.getTestResourceAbsoluteFilePath("IEDriverServer.exe"));
        driver = new InternetExplorerDriver();
    }

    public static void useFirefoxAsBrowser() {
        System.setProperty("webdriver.gecko.driver", CommonUtils.getTestResourceAbsoluteFilePath("geckodriver.exe"));
        driver = new FirefoxDriver();

    }

    public static void useChromeAsBrowser() {
    	String osType = System.getProperty("os.name");
		String hostMachine = "localhost";
    	
		if(osType.equalsIgnoreCase("LINUX")){
    		hostMachine = "remote";
    	}
		
        if (osType.equalsIgnoreCase("LINUX")) {
            System.setProperty("webdriver.chrome.driver", CommonUtils.getTestResourceAbsoluteFilePath("binaries/" + hostMachine + "/chromedriver_linux"));
        } else if (osType.contains("Mac")){
        	System.setProperty("webdriver.chrome.driver", CommonUtils.getTestResourceAbsoluteFilePath("binaries/" + hostMachine + "/chromedriver_mac"));
        } else {
            System.setProperty("webdriver.chrome.driver", CommonUtils.getTestResourceAbsoluteFilePath("binaries/" + hostMachine + "/chromedriver.exe"));
        }
        ChromeOptions options = new ChromeOptions();
        LoggingPreferences logs = new LoggingPreferences();
        logs.enable( LogType.BROWSER,  Level.ALL  );
        DesiredCapabilities capabilities = DesiredCapabilities.chrome();
        capabilities.setCapability( CapabilityType.LOGGING_PREFS, logs );
       // options.setCapability(hostMachine, capabilities);
       
        options.addArguments("--headless");
        options.addArguments("--privileged");
        options.addArguments("--no-sandbox");
        options.addArguments("--start-maximized");
        options.addArguments("--enable-logging");
        options.addArguments("--v=1");
        options.addArguments("--no-default-browser-check");
        options.addArguments("--no-first-run");

        
        driver = new ChromeDriver(options);        
    }

    public static void maximize() {
       // driver.manage().window().maximize();
    }

    public static void navigateToURL(String url) {
        driver.get(url);
    }
}
