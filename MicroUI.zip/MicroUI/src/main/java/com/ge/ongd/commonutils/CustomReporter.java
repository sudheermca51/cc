package com.ge.ongd.commonutils;

import ru.yandex.qatools.allure.annotations.Attachment;

public class CustomReporter {

    @Attachment(value = "{0}", type = "text/plain")
    public static byte[] attachTextFile(String attachmentName, String file) {
        return file.getBytes();
    }

    @Attachment(value = "{0} : xlsx attachment")
    public static byte[] attachXLSXFile(String attachmentName, String file) {
        return file.getBytes();
    }

    @Attachment(value = "{0} : xml attachment", type = "text/xml")
    public static byte[] attachXMLFile(String attachmentName, String file) {
        return file.getBytes();
    }

    @Attachment(value = "{0} : json attachment", type = "text/json")
    public static byte[] attachJSONFile(String attachmentName, String file) {
        return file.getBytes();
    }

    @Attachment(value = "csv attachment", type = "text/csv")
    public static byte[] saveCsvAttachment(String file) throws Exception {
        return file.getBytes();
    }

}
