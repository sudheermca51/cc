package com.ge.ongd.commonutils;

import java.io.*;
import java.util.*;

import org.apache.commons.logging.*;
import org.testng.xml.*;

import com.ge.ongd.commonutils.MicroAPIBase;

public class ConstructTestNgXML extends MicroAPIBase{

	private static Log logger = LogFactory.getLog(ConstructTestNgXML.class);

	/**
	 * constructTestNgXml(String suiteName, String TestName, String packageName, String apiXMLFilePath, String[] includedTags, String[] excludedTags, int threadCount, String... parallelMode)
	 * 
	 * suiteName = Suite Name, testName = Tests Name, packageName = Package Name, 
	 * apiXmlPath = Reads file api.xml or ui.xml, includeTags = Tags to Include, excludeTags = Tags to Exclude
	 * threadCount = Enter no of threads to trigger
	 * 
	 * @return Replaces the existing api.xml or ui.xml with the on the fly constructed testng xml content + parallel execution mode at method Level
	 */
	public static void constructTestNgXml(String suiteName, String testName, String packageName, String xmlFilePath, String[] includedTags, String[] excludedTags, int threadCount){		
		FileWriter writer;
		String finalTestNgXml;
		
		try {
			//XML Suite
			XmlSuite suite = new XmlSuite();
			suite.setName(suiteName);
			suite.setVerbose(1);
			suite.setPreserveOrder("true");
			if(threadCount>1){
				suite.setParallel(XmlSuite.ParallelMode.METHODS);
				suite.setThreadCount(threadCount);
			}
			
			//XML Test
			XmlTest xmlTest = new XmlTest(suite);
			xmlTest.setName(testName);
	
//			//XML Group Metadata
//			List<String> groupsMetaData = new ArrayList<String>();
//			groupsMetaData.add(Tags.SMOKE);		
//			xmlTest.addMetaGroup("Meta Group Name",groupsMetaData);
	
			//XML Groups
			for(int i = 0; i < includedTags.length ; i++){
				xmlTest.addIncludedGroup(includedTags[i]);
			}
			for(int j = 0; j < excludedTags.length ; j++){
				xmlTest.addExcludedGroup(excludedTags[j]);
			}
			
			//XML Packages
			List<XmlPackage> xmlPackages = new ArrayList<XmlPackage>();	   	   
			xmlPackages.add(new XmlPackage(packageName));
			xmlTest.setPackages(xmlPackages);
					
			finalTestNgXml = suite.toXml();				        
	        writer = new FileWriter(xmlFilePath);
			writer.write(finalTestNgXml);
			writer.close();	        
			logger.info("\n" + finalTestNgXml);
			
		} catch (IOException e) {
			logger.info(e);
		}
	}
	
	/**
	 * constructTestNgXml(String suiteName, String TestName, String packageName, String apiXMLFilePath, String[] includedTags, String[] excludedTags, String... parallelMode)
	 * 
	 * suiteName = Suite Name, testName = Tests Name, packageName = Package Name, 
	 * apiXmlPath = Reads file api.xml or ui.xml, includeTags = Tags to Include, excludeTags = Tags to Exclude
	 * 
	 * parallelMode = Optional variable for parallel execution. For parallel execution, send value as "parallel"
	 *  
	 * @return Replaces the existing api.xml or ui.xml with the on the fly constructed testng xml content + parallel execution mode at method Level with 3 thread count
	 */
	public static void constructTestNgXml(String suiteName, String testName, String packageName, String xmlFilePath, String[] includedTags, String[] excludedTags, String... parallelMode){		
		FileWriter writer;
		String finalTestNgXml;
		
		try {
			//XML Suite
			XmlSuite suite = new XmlSuite();
			suite.setName(suiteName);
			suite.setVerbose(1);
			suite.setPreserveOrder("true");
			if(parallelMode != null && parallelMode.length>=1){
				if(parallelMode[0] != null && parallelMode[0].equals("parallel")){
					suite.setParallel(XmlSuite.ParallelMode.METHODS);
					suite.setThreadCount(3);
				}
			}
			
			//XML Test
			XmlTest xmlTest = new XmlTest(suite);
			xmlTest.setName(testName);
	
			//XML Groups
			for(int i = 0; i < includedTags.length ; i++){
				xmlTest.addIncludedGroup(includedTags[i]);
			}
			for(int j = 0; j < excludedTags.length ; j++){
				xmlTest.addExcludedGroup(excludedTags[j]);
			}
			
			//XML Packages
			List<XmlPackage> xmlPackages = new ArrayList<XmlPackage>();	   	   
			xmlPackages.add(new XmlPackage(packageName));
			xmlTest.setPackages(xmlPackages);
					
			finalTestNgXml = suite.toXml();				        
	        writer = new FileWriter(xmlFilePath);
			writer.write(finalTestNgXml);
			writer.close();	        
			logger.info("\n" + finalTestNgXml);
			
		} catch (IOException e) {
			logger.info(e);
		}
	}
}
